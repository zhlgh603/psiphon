virtual_derivation
#
# very innocent example
#
b = B(3);
if (b.get_a() != b.get_b())
  error("something is really wrong")
endif

