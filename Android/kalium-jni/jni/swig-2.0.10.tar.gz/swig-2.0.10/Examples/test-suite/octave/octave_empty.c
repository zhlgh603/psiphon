/* empty C file for the Octave test-suite C tests is needed - build system workaround as the generated files for Octave are C++ files */
