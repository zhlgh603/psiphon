null_pointer;

assert(func([]));
