typemap_namespace

if (!strcmp(test1("hello"),"hello"))
    error
endif

if (!strcmp(test2("hello"),"hello"))
    error
endif

