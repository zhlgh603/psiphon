global_ns_arg

a = foo(1);
b = bar_fn();

