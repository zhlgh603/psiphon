from template_tbase_template import *

a = make_Class_dd()
if a.test() != "test":
	raise RuntimeError
