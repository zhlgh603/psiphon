from python_append import *
t=Test()
t.func()
t.static_func()
