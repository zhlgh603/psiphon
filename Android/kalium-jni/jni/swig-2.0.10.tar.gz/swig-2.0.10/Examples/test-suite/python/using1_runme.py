import using1

if using1.spam(37) != 37:
    raise RuntimeError
